<?php

define('DB_HOST', '172.20.227.241');
define('DB_USER', 'grupo1_2425');   
define('DB_PASS', 'FeGh-[69z_8)@ktC');
define('DB', 'grupo1_2425');  

define("DEFAULT_CONTROLLER", "User");
define("DEFAULT_ACTION", "login");