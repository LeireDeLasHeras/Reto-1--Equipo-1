<div class="footer">
            <link rel="stylesheet" href="assets/css/comunes_style.css">
            <img src="assets/img/logo_aergibide_letras.png" alt="Aergibide Logo" width="13%">
        </div>
    </div>
</body>